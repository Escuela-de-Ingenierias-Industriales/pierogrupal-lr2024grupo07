Project: Piero24

Proyecto de Antonio Muñoz para el robot movil Piero